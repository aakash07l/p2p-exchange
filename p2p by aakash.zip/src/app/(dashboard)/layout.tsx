import { Sidebar } from '@/components/dashboard/Sidebar';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-white text-[#17161c]">
      <Sidebar />
      <main className="app-main">{children}</main>
    </div>
  );
}
