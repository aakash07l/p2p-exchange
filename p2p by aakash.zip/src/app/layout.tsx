import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from './providers';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'P2P Exchange — Buy & Sell Crypto Instantly',
  description:
    'The fastest, most secure P2P crypto exchange platform. Buy and sell Bitcoin, Ethereum, USDT and more with INR instantly.',
  keywords: ['P2P exchange', 'crypto', 'bitcoin', 'USDT', 'INR', 'buy crypto', 'sell crypto'],
  openGraph: {
    title: 'P2P Exchange',
    description: 'Buy & Sell Crypto Instantly',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
