'use client';

import { usePrivy, useWallets } from '@privy-io/react-auth';
import { useState, useCallback } from 'react';
import type { Wallet } from '@/types';

export function useWallet() {
  const { authenticated } = usePrivy();
  const { wallets } = useWallets();
  const [dbWallet, setDbWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(false);

  const embeddedWallet = wallets.find((w) => w.walletClientType === 'privy');
  const externalWallet = wallets.find((w) => w.walletClientType !== 'privy');
  const activeWallet = embeddedWallet || externalWallet || null;

  const fetchWallet = useCallback(async () => {
    if (!authenticated) return;
    setLoading(true);
    try {
      const res = await fetch('/api/wallet');
      if (res.ok) {
        const data = await res.json();
        setDbWallet(data.data);
      }
    } finally {
      setLoading(false);
    }
  }, [authenticated]);

  const deposit = useCallback(async (asset: string, amount: number) => {
    const res = await fetch('/api/wallet/deposit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ asset, amount, walletAddress: activeWallet?.address }),
    });
    return res.json();
  }, [activeWallet]);

  const withdraw = useCallback(async (asset: string, amount: number, toAddress: string, upiId?: string) => {
    const res = await fetch('/api/wallet/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ asset, amount, toAddress, upiId }),
    });
    return res.json();
  }, []);

  return {
    activeWallet,
    embeddedWallet,
    externalWallet,
    wallets,
    dbWallet,
    loading,
    fetchWallet,
    deposit,
    withdraw,
  };
}
