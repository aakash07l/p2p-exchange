import type { PrivyClientConfig } from '@privy-io/react-auth';

export const privyConfig: PrivyClientConfig = {
  loginMethods: ['email', 'google', 'wallet'],
  appearance: {
    theme: 'dark',
    accentColor: '#6366f1',
    showWalletLoginFirst: false,
    loginMessage: 'Welcome to P2P Exchange — Trade Crypto Securely',
    walletChainType: 'ethereum-only',
  },
  embeddedWallets: {
    ethereum: {
      createOnLogin: 'users-without-wallets',
    },
  },
  mfa: {
    noPromptOnMfaRequired: false,
  },
};
