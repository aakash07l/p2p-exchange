import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { PrivyClient } from '@privy-io/server-auth';

const PROTECTED_ROUTES = ['/dashboard', '/buy', '/sell', '/wallet', '/transactions', '/referrals', '/limits', '/help', '/settings'];
const AUTH_ROUTES = ['/login'];

function isProtectedRoute(pathname: string): boolean {
  return PROTECTED_ROUTES.some((route) => pathname.startsWith(route));
}

function isAuthRoute(pathname: string): boolean {
  return AUTH_ROUTES.some((route) => pathname.startsWith(route));
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const authToken = request.cookies.get('privy-token')?.value;

  // If accessing protected route without token → redirect to login
  if (isProtectedRoute(pathname)) {
    if (!authToken) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }

    // Optionally verify token server-side (recommended for production)
    try {
      const client = new PrivyClient(
        process.env.NEXT_PUBLIC_PRIVY_APP_ID!,
        process.env.PRIVY_APP_SECRET!
      );
      await client.verifyAuthToken(authToken);
    } catch {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      const response = NextResponse.redirect(loginUrl);
      response.cookies.delete('privy-token');
      return response;
    }
  }

  // If accessing auth route with valid token → redirect to dashboard
  if (isAuthRoute(pathname) && authToken) {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico|logo.png|images).*)',
  ],
};
